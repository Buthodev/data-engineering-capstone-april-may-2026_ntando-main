--- Check duplicates in the staging table for analysis

WITH Duplicates AS
(
    SELECT
    client_number,
    first_name,
    last_name,
    email,
    mobile_number,
    date_of_birth,
    gender,
    province,
    city,
    signup_date,
    event_type,
    event_date,
    account_number,
    product_type,
    account_status,
    credit_limit,
    loan_amount,
    account_balance,
    channel,
    interaction_type,
    resolved_flag,
    transaction_type,
    amount,
        ROW_NUMBER() OVER (
            PARTITION BY Email
            ORDER BY
            client_number,
    first_name,
    last_name,
    email,
    mobile_number,
    date_of_birth,
    gender,
    province,
    city,
    signup_date,
    event_type,
    event_date,
    account_number,
    product_type,
    account_status,
    credit_limit,
    loan_amount,
    account_balance,
    channel,
    interaction_type,
    resolved_flag,
    transaction_type,
    amount
        ) AS RowNum
    FROM staging.customer_activity_extract
)
SELECT *
FROM Duplicates
WHERE RowNum > 1;

--- Client number, Account Number, Signup Date, Event Type, Amount and Event Date are columns that can be used to identify duplicates in the staging table.
--- The SQL query below will preview the duplicates based on these columns that idenify accurate duplicates.

WITH Duplicates AS
(
    SELECT
        client_number,
        account_number,
        signup_date,
        event_type,
        event_date,
        amount,
        ROW_NUMBER() OVER (
            PARTITION BY
                client_number,
                account_number,
                signup_date,
                event_type,
                event_date,
                amount
            ORDER BY client_number
        ) AS RowNum
    FROM staging.customer_activity_extract
)
SELECT *
FROM Duplicates
WHERE RowNum > 1;

--- Now that we have identified the duplicates, we can delete them from the staging table. The SQL query below will delete the duplicates based on the columns that identify accurate duplicates.

WITH Duplicates AS
( 
SELECT
client_number,
account_number,
signup_date,
event_type,
event_date,
amount,
ROW_NUMBER() OVER (
PARTITION BY
client_number,
account_number,
signup_date,
event_type,
event_date,
amount
ORDER BY client_number
) AS RowNum
FROM staging.customer_activity_extract
)
DELETE FROM Duplicates
WHERE RowNum > 1;

--- We can verify that the duplicates have been deleted from the staging table by running the query below. The query will return no results if the duplicates have been successfully deleted.

WITH Duplicates AS
(
    SELECT
        client_number,
        account_number,
        signup_date,
        event_type,
        event_date,
        amount,
        ROW_NUMBER() OVER (
            PARTITION BY
                client_number,
                account_number,
                signup_date,
                event_type,
                event_date,
                amount
            ORDER BY client_number
        ) AS RowNum
    FROM staging.customer_activity_extract
)
SELECT *
FROM Duplicates
WHERE RowNum > 1;


--- Verify entire staging table deduplication.

WITH Duplicates AS
(
    SELECT
    client_number,
    first_name,
    last_name,
    email,
    mobile_number,
    date_of_birth,
    gender,
    province,
    city,
    signup_date,
    event_type,
    event_date,
    account_number,
    product_type,
    account_status,
    credit_limit,
    loan_amount,
    account_balance,
    channel,
    interaction_type,
    resolved_flag,
    transaction_type,
    amount,
        ROW_NUMBER() OVER (
            PARTITION BY Email
            ORDER BY
            client_number,
    first_name,
    last_name,
    email,
    mobile_number,
    date_of_birth,
    gender,
    province,
    city,
    signup_date,
    event_type,
    event_date,
    account_number,
    product_type,
    account_status,
    credit_limit,
    loan_amount,
    account_balance,
    channel,
    interaction_type,
    resolved_flag,
    transaction_type,
    amount
        ) AS RowNum
    FROM staging.customer_activity_extract
)
SELECT *
FROM Duplicates
WHERE RowNum > 1;


----------------------------------------------------------------------------------

--- ETL Pipeline Statement 'Dedup and Clean' Package
--- SQL statement only deletes duplicates if found in the data

IF EXISTS (
    SELECT 1
    FROM staging.customer_activity_extract
    GROUP BY
        client_number,
        account_number,
        signup_date,
        event_type,
        event_date,
        amount
    HAVING COUNT(*) > 1
)
BEGIN

    WITH Duplicates AS
    (
        SELECT
            client_number,
            account_number,
            signup_date,
            event_type,
            event_date,
            amount,
            ROW_NUMBER() OVER (
                PARTITION BY
                    client_number,
                    account_number,
                    signup_date,
                    event_type,
                    event_date,
                    amount
                ORDER BY client_number
            ) AS RowNum
        FROM staging.customer_activity_extract
    )
    DELETE FROM Duplicates
    WHERE RowNum > 1;

    PRINT 'Duplicate records found and removed successfully.';
END
ELSE
BEGIN
    PRINT 'No duplicate records found. No deletion was performed.';
END;
